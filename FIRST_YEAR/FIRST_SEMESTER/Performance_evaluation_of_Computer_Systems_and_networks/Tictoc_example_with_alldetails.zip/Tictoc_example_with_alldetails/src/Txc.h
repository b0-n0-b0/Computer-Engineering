

#ifndef __HHH_TCX_H
#define __HHH_TCX_H

#include <omnetpp.h> //this contains useful containers as cArrays, cQueue classes
                     //most of simulation objects derive from cObject (that defines several virtual member functions, inherited by subclasses)

using namespace omnetpp;

namespace hhh {

/**
 * Implements the Txc simple module. See the NED file for more information.
 */
class Txc : public cSimpleModule //it is a sub class o Simplemodule class
{
  protected:
    virtual void initialize();
    virtual void handleMessage(cMessage *msg);


  private:
    cMessage *beep_;  //for timer
    simsignal_t delaySignal; //for metric

    //if it has a compound module, it can be useful to retrieve the pointer to its parent
    cModule * pc;
    pc = getParentModule(); //usually it has to be done inside a settere/getter function, in order to add error control
    pc = findModuleByPath("pc2.hd1"); //to  find submodule of a compound module, you need to specify the relative or absolute path

    int size = pc->getSize(); //retrieve size, that is a parameter of the compound module
};

}; // namespace







#endif
