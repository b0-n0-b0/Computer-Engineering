
//the behavior is coded in this c++ file and defines how the module reacts to (handles) events
//this file has to be created just for simple modules, not compound. Their behavior is just the summation of their composing modules
//Also a network doesn't have a behavior, because it is just the top-level compound module
#include "Txc.h"

namespace hhh {

Define_Module(Txc); //macro used to insert the NED file code, used for optimization issues

void Txc::initialize() //this function is called automatically after a module is created and is generally used to perform setup operations on a module
{

    registerSignal("delay"); //the parameter "delay" must correspond to the source string defined in NED file

    if (par("sendInitialMessage").boolValue())
    {
        cMessage *msg = new cMessage("tictocMsg"); //msg is a c++ object, has "owner" field which indicate the current owner
                                                   //during the "flight", the owner is event_queue
                                                   //at the arrival time, owner is the destination module
                                                   // [ownership gives the right to delete the object]

        send(msg, "out"); //is used for sending out messages through an output gate, "out" name is the name defined in NED file
                          //generates a new event at a point that depends on the connection parameters
                          //no mention for toc receiver, thus the code is flexible
        /*
         * sending equals to event creation by Omnet that has:
         *      -the reception time of the message at toc as arrival time (firing time)
         *      -a priority
         *      -the toc module as entity that will handle the message
         *
         * That event is inserted in the event queue [it is a Forward Event Set, FES, implemented as a binary heap]
         * When simulation time = arrival time of the message --> handleMessage() is executed by the receiver module
         *
         */


      //scheduleAt()  is used by a module to send a message to itself, the message owner remains the same
      //this function is used to implement timer, in order to have a periodic event or after a defined amount of time
      //At the end of the story, a simple module can create a timer by sending a message to itself

      //cancelEvent() is used to cancel a timer: remove an event from the event queue


       //for timer
        beep_ = new cMessage("beep");
    }
}


//events are placed in timeline, after an event is managed, the next nearest is executed
void Txc::handleMessage(cMessage *msg) //events are reception of messages by a module
      //this called whenever a message is received by a simple module
{     //this function can create one or more events when manages another one, so new events can be added to the timeline

    //check message type
    /*
     * if( strcmp(msg->getName(),"tictocMsg") == 0) //getName() return a string with the name(type) of a message
     *      {
     *          do stuff
     *      }
     */

  /* scheduling the message to be sent
   *
   * if( strcmp(msg->getName(),"tictocMsg") == 0) {
   *        simtime_t time = par("procTime"); //used in order to avoid specifying every time the temporal instant
   *                                          //function par() reads the value of a parameter, it is fixed, set only once
   *
   *        //how to generate random time between 0 and 10 uniformly distributed
   *        double time_ = uniform(0,10);
   *
   *        scheduleAt( simTime() + time, beep_); //the first parameter indicates when the message beep_ is received
   *
   *        tictocMsg_ = msg; //store for later transmission
   * }
   * else if(msg->isSelfMessage())   //checking if msg == beep, if true send the message to the other module
   *                                  //isSelfMessage return true if the given message was scheduled via the scheduleAt function
   *
   */
        send(msg, "out"); // just send back the message we received

        emit(delaySignal, value); //write value into the signal (defined in .h file)  via emit(name, value)
}

}; // namespace
