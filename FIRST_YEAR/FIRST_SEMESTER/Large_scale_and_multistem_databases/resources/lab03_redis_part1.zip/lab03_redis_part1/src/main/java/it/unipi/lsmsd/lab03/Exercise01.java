package it.unipi.lsmsd.lab03;

import it.unipi.lsmsd.lab03.shoppingcart.manager.ShoppingCartManager;
import it.unipi.lsmsd.lab03.shoppingcart.model.ShoppingCart;
import it.unipi.lsmsd.lab03.shoppingcart.model.ShoppingCartItem;

public class Exercise01 {

    public static void main(String[] args) throws InterruptedException {

        Runtime.getRuntime().addShutdownHook(new Thread(new Runnable() {
            public void run() {
                ShoppingCartManager.closePool();
            }
        }, "Shutdown-thread"));

        Integer userId = 1;
        ShoppingCart shoppingCart = new ShoppingCart(userId);
        shoppingCart.addProduct(1001, "Coca cola", 2);
        shoppingCart.addProduct(new ShoppingCartItem(1002, "Doritos", 4));
        shoppingCart.addProduct(1003, "Snickers", 2);

        System.out.println("Shopping cart persisted.");
        ShoppingCartManager.persist(shoppingCart);
        ShoppingCart loaded = ShoppingCartManager.load(userId);

        System.out.println("Shopping cart loaded: " + loaded);
        System.out.println("Verify whether the cart exist or not after 60 seconds.");

        Thread.sleep(61*1000);

        loaded = ShoppingCartManager.load(userId);
        System.out.println("Shopping cart loaded: " + loaded);

    }

}
