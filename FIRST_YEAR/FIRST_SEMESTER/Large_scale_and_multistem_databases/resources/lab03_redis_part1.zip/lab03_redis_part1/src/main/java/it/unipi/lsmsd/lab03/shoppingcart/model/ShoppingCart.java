package it.unipi.lsmsd.lab03.shoppingcart.model;

import java.util.ArrayList;
import java.util.List;

public class ShoppingCart {

    private Integer userId;
    private List<ShoppingCartItem> products;

    public ShoppingCart(Integer userId) {
        this.userId = userId;
        this.products = new ArrayList<ShoppingCartItem>();
    }

    public void addProduct(Integer productId, String productName, Integer quantity){
        products.add(new ShoppingCartItem(productId, productName, quantity));
    }

    public void addProduct(ShoppingCartItem shoppingCartItem){
        products.add(shoppingCartItem);
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public List<ShoppingCartItem> getProducts() {
        return products;
    }

    public void setProducts(List<ShoppingCartItem> products) {
        this.products = products;
    }

    @Override
    public String toString() {
        return "ShoppingCart{" +
                "userId=" + userId +
                ", products=" + products +
                '}';
    }
}
