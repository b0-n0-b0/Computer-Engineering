package it.unipi.lsmsd.lab03.ticketshospital.manager;

import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPool;
import redis.clients.jedis.Transaction;

import java.util.List;

public class TicketManager {

    private static final JedisPool pool;
    private static final String REDIS_HOST = "localhost";
    private static final Integer REDIS_PORT = 6379;
    private static final String COUNTER_KEY_NS = "hospital-tickets:counter";
    private static final Integer totalNumberOfTickets = 100;

    static {
        pool = new JedisPool(REDIS_HOST, REDIS_PORT);
        try (Jedis jedis = pool.getResource()) {
            jedis.set(COUNTER_KEY_NS, totalNumberOfTickets + "");
        }
    }

    public static int getCurrentTicketNumber(){
        try (Jedis jedis = pool.getResource()) {
            return Integer.parseInt(jedis.get(COUNTER_KEY_NS));
        }
    }

    private TicketManager(){
    }

    public static int getTicketNumber(){
        try (Jedis jedis = pool.getResource()) {
            jedis.watch(COUNTER_KEY_NS);
            Integer currentCounter = Integer.parseInt(jedis.get(COUNTER_KEY_NS));
            if (currentCounter == 0){
                return -1;
            }
            Integer newValueCounter = currentCounter - 1;
            Transaction transaction = jedis.multi();
            transaction.set(COUNTER_KEY_NS, newValueCounter + "");
            List<Object> result = transaction.exec();
            if (result != null) {
                return currentCounter;
            }
            return getTicketNumber();
        }
    }

    public static void closePool(){
        if (!pool.isClosed()){
            pool.close();
        }
    }

}
