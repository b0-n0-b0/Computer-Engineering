package it.unipi.lsmsd.lab03.shoppingcart.manager;

import com.google.gson.Gson;
import it.unipi.lsmsd.lab03.shoppingcart.model.ShoppingCart;
import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPool;

public class ShoppingCartManager {

    private static final JedisPool pool;
    private static final String REDIS_HOST = "localhost";
    private static final Integer REDIS_PORT = 6379;
    private static final String APP_NS = "shopping-cart";

    static {
        pool = new JedisPool(REDIS_HOST, REDIS_PORT);
    }


    private static String shoppingCartItemsKeyNS(Integer userId) {
        return APP_NS + ":" + userId + ":items";
    }

    private static String shoppingCartUpdatedDateKeyNS(Integer userId) {
        return APP_NS + ":" + userId + ":updatedDate";
    }

    public static void persist(ShoppingCart shoppingCart) {
        Gson gson = new Gson();
        Integer userId = shoppingCart.getUserId();
        String shoppingCartKey = shoppingCartItemsKeyNS(userId);
        String updatedDateKey = shoppingCartUpdatedDateKeyNS(userId);
        System.out.println("Shopping cart items key: " + shoppingCartKey);
        System.out.println("Shopping cart updatedDateKey key: " + updatedDateKey);
        try (Jedis jedis = pool.getResource()) {
            jedis.set(shoppingCartKey, gson.toJson(shoppingCart));
            jedis.set(updatedDateKey, System.currentTimeMillis() + "");
            jedis.expire(shoppingCartKey, 60);
        }
    }

    public static ShoppingCart load(Integer userId) {
        Gson gson = new Gson();
        String shoppingCartKey = shoppingCartItemsKeyNS(userId);
        System.out.println("Shopping cart key: " + shoppingCartKey);
        try (Jedis jedis = pool.getResource()) {
            String data = jedis.get(shoppingCartKey);
            if (data != null){
                System.out.println("Data from Redis: " + data);
                return gson.fromJson(data, ShoppingCart.class);
            }
        }
        return null;
    }

    public static void closePool(){
        if (!pool.isClosed()){
            pool.close();
        }
    }
}
