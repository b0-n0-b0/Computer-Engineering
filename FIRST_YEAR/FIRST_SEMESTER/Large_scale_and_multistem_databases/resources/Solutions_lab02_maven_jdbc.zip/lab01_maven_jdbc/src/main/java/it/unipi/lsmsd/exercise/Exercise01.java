package it.unipi.lsmsd.exercise;


import it.unipi.lsmsd.exercise.model.Company;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.stream.Collectors;

public class Exercise01 {
    private static final String MYSQL_HOST = "localhost";
    private static final Integer MYSQL_PORT = 3306;
    private static final String MYSQL_DATABASE = "unipi";
    private static final String MYSQL_USERNAME = "jose";
    private static final String MYSQL_PASSWORD = "jose";
    // format: mysql://<username>:<password>@<host>:<port>/<db_name>
    private static final String JDBC_URL = "jdbc:mysql://%s:%s@%s:%d/%s";

    public Connection getConnection() throws SQLException {
        String jdbcUrl = String.format(JDBC_URL, MYSQL_USERNAME, MYSQL_PASSWORD, MYSQL_HOST, MYSQL_PORT, MYSQL_DATABASE);
        Properties properties = new Properties();
        properties.put("zeroDateTimeBehavior", "CONVERT_TO_NULL");
        properties.put("serverTimeZone", "CET");
        return DriverManager.getConnection(jdbcUrl, properties);
    }

    public int insertTuples(List<Company> companies) {
        StringBuilder sql = new StringBuilder();
        sql.append("insert into company(name, address, employee_count, website) ");
        sql.append("values(?, ?, ?, ?) ");
        try(
                Connection connection = getConnection();
                PreparedStatement preparedStatement = connection.prepareStatement(sql.toString());
        ){
                int affectedRows = 0;
                for(Company company: companies){
                    preparedStatement.setString(1, company.getName());
                    preparedStatement.setString(2, company.getAddress());
                    preparedStatement.setInt(3, company.getEmployeeCount());
                    preparedStatement.setString(4, company.getWebSite());
                    affectedRows += preparedStatement.executeUpdate();
                }
                System.out.println("Number of inserted rows: " + affectedRows);
                return affectedRows;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public void listTuples(){
        try(
                Connection connection = getConnection();
                Statement    statement = connection.createStatement();
                ResultSet    resultSet = statement.executeQuery("select id, name, address, employee_count, website from company order by name asc");
        ){
            while (resultSet.next()) {
                Integer id = resultSet.getInt("id");
                String name = resultSet.getString("name");
                String address = resultSet.getString("address");
                Integer employeeCount = resultSet.getInt("employee_count");
                String website = resultSet.getString("website");
                System.out.format("%d) %s, %s, %d, %s \n", id, name, address, employeeCount, website);
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public int deleteTuples() {
        try(
                Connection connection = getConnection();
                Statement    statement = connection.createStatement();
        ){
            int affectedRows = statement.executeUpdate("delete from company");
            System.out.println("Number of deleted rows: " + affectedRows);
            return affectedRows;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
    public static void main(String[] args) {
        List<Company> companies = new ArrayList<Company>();
        companies.add(new Company("UNIPI", "Lungarno Galilei, Pisa", 5000, "https://www.unipi.it"));
        companies.add(new Company("UNIFI", "Firenze", 4999, "https://www.unifi.it"));
        companies.add(new Company("UNITO", "Torino", 5000, "https://www.unito.it"));

        Exercise01 exercise01 = new Exercise01();

        exercise01.insertTuples(companies);
        exercise01.listTuples();
        exercise01.deleteTuples();
    }
}