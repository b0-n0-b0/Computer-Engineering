package it.unipi.lsmsd.example;

import java.sql.*;

public class ExampleConnect {

    public static void main(String[] args) {
        Connection connection = null;
        try{
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/unipi", "jose", "jose");
            // Do something...
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }  finally{
            if (connection != null) {
                try { connection.close();} catch (SQLException e) {}
            }
        }
    }
}
