package it.unipi.lsmsd.example;

import java.sql.*;
import java.util.Properties;

public class Example02 {
    private static final String MYSQL_HOST = "localhost";
    private static final Integer MYSQL_PORT = 3306;
    private static final String MYSQL_DATABASE = "unipi";
    private static final String MYSQL_USERNAME = "jose";
    private static final String MYSQL_PASSWORD = "jose";
    // format: mysql://<username>:<password>@<host>:<port>/<db_name>
    private static final String JDBC_URL = "jdbc:mysql://%s:%s@%s:%d/%s";

    public static void main(String[] args) {
        String jdbcUrl = String.format(JDBC_URL, MYSQL_USERNAME, MYSQL_PASSWORD, MYSQL_HOST, MYSQL_PORT, MYSQL_DATABASE);
        Properties properties = new Properties();
        properties.put("zeroDateTimeBehavior", "CONVERT_TO_NULL");
        properties.put("serverTimeZone", "CET");
        try(
                Connection connection = DriverManager.getConnection(jdbcUrl, properties);
                Statement    statement = connection.createStatement();
                ResultSet    resultSet = statement.executeQuery("select id, name from employee order by name asc");
           ){
            while (resultSet.next()) {
                Integer id = resultSet.getInt("id");
                String name = resultSet.getString("name");
                System.out.format("%d) %s \n", id, name);
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
}