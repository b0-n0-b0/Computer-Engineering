package it.unipi.lsmsd.exercise.dao.base;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public abstract class BaseDAO {

    private static final String MYSQL_HOST = "localhost";
    private static final Integer MYSQL_PORT = 3306;
    private static final String MYSQL_DATABASE = "unipi";
    private static final String MYSQL_USERNAME = "jose";
    private static final String MYSQL_PASSWORD = "jose";
    // format: mysql://<username>:<password>@<host>:<port>/<db_name>
    private static final String JDBC_URL = "jdbc:mysql://%s:%s@%s:%d/%s";

    public Connection getConnection() throws SQLException {
        String jdbcUrl = String.format(JDBC_URL, MYSQL_USERNAME, MYSQL_PASSWORD, MYSQL_HOST, MYSQL_PORT, MYSQL_DATABASE);
        Properties properties = new Properties();
        properties.put("zeroDateTimeBehavior", "CONVERT_TO_NULL");
        properties.put("serverTimeZone", "CET");
        return DriverManager.getConnection(jdbcUrl, properties);
    }

}
