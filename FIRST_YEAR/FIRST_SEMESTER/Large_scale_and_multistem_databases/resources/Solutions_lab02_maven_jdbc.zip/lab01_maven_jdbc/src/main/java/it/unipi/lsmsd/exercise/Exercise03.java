package it.unipi.lsmsd.exercise;

import it.unipi.lsmsd.exercise.dao.AuthorDAO;
import it.unipi.lsmsd.exercise.dto.AuthorDTO;

import java.util.List;

public class Exercise03 {

    public static void main(String[] args){
        String firstNameFilter = "F";
        String lastNameFilter = "O";
        List<AuthorDTO> listOfAuthors = new AuthorDAO().listAuthors(firstNameFilter, lastNameFilter);
        System.out.format("Total number of results: %d \n", listOfAuthors.size());
        listOfAuthors.stream().forEach(authorDTO -> {
            System.out.println(authorDTO);
        });
    }
}
