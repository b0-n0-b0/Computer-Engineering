package it.unipi.lsmsd.exercise.dao;

import it.unipi.lsmsd.exercise.dao.base.BaseDAO;
import it.unipi.lsmsd.exercise.dto.AuthorDTO;
import it.unipi.lsmsd.exercise.model.Author;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/*
Take a look: https://dev.mysql.com/doc/refman/8.0/en/select.html
 */
public class AuthorDAO extends BaseDAO {

    public void create(Author author){
        // TODO
    }

    /*
        Homework: Modify this method to support paging.
                  This method must receive two parameters:
                        - pageNumber -> It specifies the page number to retrieve
                        - rowsPerPage -> It specifies the number of records to retrieve by page
     */
    public List<AuthorDTO> listAuthors(String firstName,
                                       String lastName){
        List<AuthorDTO> authorDTOList = new ArrayList<AuthorDTO>();
        StringBuilder sql = new StringBuilder();
        sql.append("select a.id, a.first_name, a.last_name, count(b.id) ");
        sql.append("from ");
        sql.append("author a ");
        sql.append("left join book_has_author bha on bha.author_id = a.id ");
        sql.append("left join book b on b.id = bha.book_id ");
        sql.append("where ");
        sql.append(" 1 = 1 ");
        if (firstName != null && !firstName.isEmpty()){
            sql.append(" and lower(a.first_name) like concat('%', lower(?), '%') ");
        }
        if (lastName != null && !lastName.isEmpty()){
            sql.append(" and lower(a.last_name) like concat('%', lower(?), '%') ");
        }
        sql.append("group by a.id, a.first_name, a.last_name ");
        sql.append("order by lower(a.last_name) ");
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        try{
            connection = super.getConnection();
            preparedStatement = connection.prepareStatement(sql.toString());
            int index = 1;
            if (firstName != null && !firstName.isEmpty()){
                preparedStatement.setString(index, firstName);
                index++;
            }
            if (lastName != null && !lastName.isEmpty()){
                preparedStatement.setString(index, lastName);
                index++;
            }
            resultSet = preparedStatement.executeQuery();
            while (resultSet.next()){
                AuthorDTO authorDTO = new AuthorDTO();
                authorDTO.setId(resultSet.getInt(1));
                authorDTO.setFirstName(resultSet.getString(2));
                authorDTO.setLastName(resultSet.getString(3));
                authorDTO.setBooksQuantity(resultSet.getInt(4));
                authorDTOList.add(authorDTO);
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return authorDTOList;
    }


}
