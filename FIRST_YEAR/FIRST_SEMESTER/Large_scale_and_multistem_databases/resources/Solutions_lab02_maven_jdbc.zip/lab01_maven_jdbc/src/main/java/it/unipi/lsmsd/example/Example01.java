package it.unipi.lsmsd.example;

import java.sql.*;

public class Example01 {

    public static void main(String[] args) {
        Connection connection = null;
        Statement statement = null;
        ResultSet resultSet = null;
        try{
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/unipi?" +
                    "zeroDateTimeBehavior=CONVERT_TO_NULL&serverTimeZone=CET", "jose", "jose");
            statement = connection.createStatement();
            resultSet = statement.executeQuery("select id, name from employee order by name asc");
            while (resultSet.next()) {
                Integer id = resultSet.getInt("id");
                String name = resultSet.getString("name");
                System.out.format("%d) %s \n", id, name);
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }  finally{
            if (resultSet != null) {
                try { resultSet.close();} catch (SQLException e) {}
            }
            if (statement != null) {
                try { statement.close();} catch (SQLException e) {}
            }
            if (connection != null) {
                try { connection.close();} catch (SQLException e) {}
            }
        }
    }
}
