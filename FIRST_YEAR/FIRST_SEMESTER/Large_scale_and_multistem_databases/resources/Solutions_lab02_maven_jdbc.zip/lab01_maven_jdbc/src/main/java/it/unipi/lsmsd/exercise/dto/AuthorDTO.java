package it.unipi.lsmsd.exercise.dto;

//Data Transfer Object
public class AuthorDTO {
    private Integer id;
    private String firstName;
    private String lastName;
    private Integer booksQuantity;

    public AuthorDTO() {
    }

    public AuthorDTO(Integer id) {
        this.id = id;
    }

    public AuthorDTO(String firstName, String lastName, Integer booksQuantity) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.booksQuantity = booksQuantity;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public Integer getBooksQuantity() {
        return booksQuantity;
    }

    public void setBooksQuantity(Integer booksQuantity) {
        this.booksQuantity = booksQuantity;
    }

    @Override
    public String toString() {
        return "AuthorDTO{" +
                "id=" + id +
                ", firstName='" + firstName + '\'' +
                ", lastName='" + lastName + '\'' +
                ", booksQuantity=" + booksQuantity +
                '}';
    }
}
