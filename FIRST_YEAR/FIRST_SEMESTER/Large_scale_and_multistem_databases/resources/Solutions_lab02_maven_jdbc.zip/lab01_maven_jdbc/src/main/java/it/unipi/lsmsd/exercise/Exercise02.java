package it.unipi.lsmsd.exercise;


import it.unipi.lsmsd.exercise.dao.BookDAO;
import it.unipi.lsmsd.exercise.model.Author;
import it.unipi.lsmsd.exercise.model.Book;
import it.unipi.lsmsd.exercise.model.Publisher;

public class Exercise02 {

    public static void main(String[] args) {
        BookDAO bookDAO = new BookDAO();
        Integer totalNumberOfBooks = 100;
        Integer authorId = 1;
        Integer publisherId = 1;
        for(int i = 2; i < totalNumberOfBooks; i++){
            Book book = new Book();
            book.setTitle("Book " + i);
            book.setPrice(19.99f);
            book.setCategory("Computer Science");
            book.setNumPages(999);
            book.setPublicationYear(2022);
            book.setQuantity(100);

            Author author = new Author(authorId);
            Publisher publisher = new Publisher(publisherId);

            book.setPublisher(publisher);
            book.addAuthor(author);
            bookDAO.create(book);
            System.out.println("New Book ID: " + book.getId());
        }
    }
}