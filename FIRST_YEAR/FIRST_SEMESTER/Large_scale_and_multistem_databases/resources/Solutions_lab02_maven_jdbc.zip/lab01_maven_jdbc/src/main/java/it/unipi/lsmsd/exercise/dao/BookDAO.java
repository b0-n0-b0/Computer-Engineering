package it.unipi.lsmsd.exercise.dao;

import it.unipi.lsmsd.exercise.dao.base.BaseDAO;
import it.unipi.lsmsd.exercise.model.Author;
import it.unipi.lsmsd.exercise.model.Book;

import java.sql.*;
import java.util.List;

public class BookDAO extends BaseDAO {

    public void create(Book book) {
        try (Connection connection = getConnection();){
            // By default the auto commit is set in true.
            connection.setAutoCommit(false);
            int newBookId = insertBook(connection, book);
            insertBookAuthor(connection, newBookId, book.getAuthors());
            // In case everything went fine, we can commit!.
            connection.commit();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    private void insertBookAuthor(Connection connection, int newBookId, List<Author> authors) {
        StringBuilder insertSQL = new StringBuilder();
        insertSQL.append("insert into book_has_author(author_id, book_id) ");
        insertSQL.append(" values (?,?)");
        try (
                PreparedStatement preparedStatement = connection.prepareStatement(insertSQL.toString());
        ) {
            for(Author author: authors){
                preparedStatement.setInt(1, author.getId());
                preparedStatement.setInt(2, newBookId);
                preparedStatement.executeUpdate();
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    private int insertBook(Connection connection, Book book){
        StringBuilder insertSQL = new StringBuilder();
        insertSQL.append("insert into book(title, price, category, publication_year, num_pages, publisher_id, quantity) ");
        insertSQL.append(" values (?,?,?,?,?,?,?)");
        try (
                PreparedStatement preparedStatement = connection.prepareStatement(insertSQL.toString(),
                        Statement.RETURN_GENERATED_KEYS);
        ) {
            preparedStatement.setString(1, book.getTitle());
            preparedStatement.setFloat(2, book.getPrice());
            preparedStatement.setString(3, book.getCategory());
            preparedStatement.setInt(4, book.getPublicationYear());
            preparedStatement.setInt(5, book.getNumPages());
            preparedStatement.setInt(6, book.getPublisher().getId());
            preparedStatement.setInt(7, book.getQuantity());

            int affectedRows = preparedStatement.executeUpdate();

            if (affectedRows == 0) {
                throw new SQLException("Creating book failed, no rows affected.");
            }

            try (ResultSet generatedKeys = preparedStatement.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    Integer generatedId = generatedKeys.getInt(1);
                    book.setId(generatedId);
                    return generatedId;
                }
                else {
                    throw new SQLException("Creating user failed, no ID obtained.");
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

}
