package it.unipi.lsmsd.exercise.model;

public class Company {

    private Integer id;
    private String name;
    private String address;
    private Integer employeeCount;
    private String webSite;

    public Company(String name, String address, Integer employeeCount, String webSite) {
        this.name = name;
        this.address = address;
        this.employeeCount = employeeCount;
        this.webSite = webSite;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public Integer getEmployeeCount() {
        return employeeCount;
    }

    public void setEmployeeCount(Integer employeeCount) {
        this.employeeCount = employeeCount;
    }

    public String getWebSite() {
        return webSite;
    }

    public void setWebSite(String webSite) {
        this.webSite = webSite;
    }
}
