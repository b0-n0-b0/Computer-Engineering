# Showing the available DB
show databases;

# Selecting the database
use unipi;

# Showing Tables (after selection of a DB)
show tables;

# Creating a Database
create database unipi;

# Example
CREATE TABLE IF NOT EXISTS employee (
    id int(11) NOT NULL AUTO_INCREMENT,
    name VARCHAR(20),
    PRIMARY KEY (id));

insert into employee(name) values ("Pietro Ducange");
insert into employee(name) values ("Jose Corcuera");
insert into employee(name) values ("Alessandro Renda");
insert into employee(name) values("Alessio Bechini");
insert into employee(name) values ("Francesco Marcelloni");
insert into employee(name) values ("Michele Baldassini");

# Exercise 1
CREATE TABLE IF NOT EXISTS company (
    id int(11) NOT NULL AUTO_INCREMENT,
    name VARCHAR(20),
    address VARCHAR(100),
    employee_count int,
    website VARCHAR(100),
    PRIMARY KEY (id)
);

insert into company(name, address, employee_count, website) values ("UNIPI", "Lungarno Galilei, Pisa", 5000, "https://www.unipi.it");
insert into company(name, address, employee_count, website) values ("UNIFI", "Firenze", 4999, "https://www.unifi.it");
insert into company(name, address, employee_count, website) values ("UNITO", "Torino", 5000, "https://www.unito.it");

#Exercise 2
CREATE TABLE `publisher` (
      `id` int(11) NOT NULL AUTO_INCREMENT,
      `name` varchar(128) NOT NULL,
      `location` varchar(128) NOT NULL,
      PRIMARY KEY (`id`)
) ENGINE=InnoDB;

CREATE TABLE `author` (
    `id` int(11) NOT NULL AUTO_INCREMENT,
    `first_name` varchar(128) NOT NULL,
    `last_name` varchar(128) NOT NULL,
    `biography` varchar(500),
    PRIMARY KEY (`id`)
) ENGINE=InnoDB;

CREATE TABLE `book` (
    `id` int(11) NOT NULL AUTO_INCREMENT,
    `title` varchar(128) NOT NULL,
    `price` float NOT NULL,
    `category` varchar(45) NOT NULL,
    `publication_year` int NOT NULL,
    `num_pages` int NOT NULL,
    `publisher_id` int NOT NULL,
    `quantity` int NOT NULL,
    PRIMARY KEY (`id`),
    UNIQUE KEY `book_title_unique` (`title`)
) ENGINE=InnoDB;

CREATE TABLE `book_has_author` (
    author_id int not null,
    book_id int not null,
    primary key (author_id, book_id)
) ENGINE=InnoDB;

ALTER TABLE book ADD CONSTRAINT fk_book_publisher
        FOREIGN KEY (publisher_id) REFERENCES publisher(id);

ALTER TABLE book_has_author ADD CONSTRAINT fk_book_has_author_001
    FOREIGN KEY (book_id) REFERENCES book(id);

ALTER TABLE book_has_author ADD CONSTRAINT fk_book_has_author_002
    FOREIGN KEY (author_id) REFERENCES author(id);

insert into publisher(name, location) values ('Publisher 1', 'Italy');
insert into author(first_name, last_name, biography) values ('First Name', 'Last Name', 'Biography here.');

# Deleting all rows
TRUNCATE TABLE <TABLE_NAME_HERE>;

# Deleting a db
DROP DATABASE <DATABASE_NAME_HERE>;

#Checking version;
SHOW VARIABLES LIKE "%version%";