package it.unipi.lsmsd.lab03.part2;

import it.unipi.lsmsd.lab03.part2.connectors.RedisConnectionManager;
import it.unipi.lsmsd.lab03.part2.ratelimiting.RequestThread;

public class Exercise03 {
    public static void main(String [] args) throws InterruptedException {

        Runtime.getRuntime().addShutdownHook(new Thread(new Runnable() {
            public void run() {
                RedisConnectionManager.getInstance().closePool();
            }
        }, "Shutdown-thread"));
        int numberOfClients = 10;
        RequestThread[] clients = new RequestThread[numberOfClients];
        //initializing threads
        for(int i = 0; i < numberOfClients; i++){
            clients[i] = new RequestThread("Client " + (i + 1));
        }
        //firing threads
        for(int i = 0; i < numberOfClients; i++){
            clients[i].start();
        }
        //waiting for them to finish
        for(int i = 0; i < numberOfClients; i++){
            clients[i].join();
        }
    }
}
