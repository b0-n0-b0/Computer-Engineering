package it.unipi.lsmsd.lab03.part2.ratelimiting;

import it.unipi.lsmsd.lab03.part2.connectors.RedisConnectionManager;
import redis.clients.jedis.Jedis;
import redis.clients.jedis.Transaction;

import java.util.Calendar;
import java.util.List;

public class MyAPI {

    private static final MyAPI instance = new MyAPI();
    private static final String MY_APP_NS = "rate-limiting";
    private static final Integer ratePerMinute = 100;

    private MyAPI(){
    }

    public static MyAPI getInstance(){
        return instance;
    }

    private String getMinuteKeyInNS(int minute){
        return MY_APP_NS + ":minute:" + minute;
    }

    public void call(String threadName){
        int currentMinute = Calendar.getInstance().get(Calendar.MINUTE);
        try (Jedis jedis = RedisConnectionManager.getInstance().getConnection()) {
            String minuteKeyInNS = getMinuteKeyInNS(currentMinute);
            /*
                SETNX: Set key to hold string value if key does not exist.
                In that case, it is equal to SET.
                When key already holds a value, no operation is performed.
                SETNX is short for "SET if Not eXists".
                Integer reply, specifically:
                    1 if the key was set
                    0 if the key was not set
                Specification: https://redis.io/commands/setnx/
             */
            boolean firstSet = (jedis.setnx(minuteKeyInNS, ratePerMinute + "") == 1);
            if (!firstSet) {
                jedis.watch(minuteKeyInNS);
                Integer currentCounter = Integer.parseInt(jedis.get(minuteKeyInNS));
                if (currentCounter == 0){
                    System.out.println("Minute " + currentMinute + ", HTTP 429 " + threadName);
                    return ;
                }
                Integer newValueCounter = currentCounter - 1;
                Transaction transaction = jedis.multi();
                transaction.set(minuteKeyInNS, newValueCounter + "");
                List<Object> result = transaction.exec();
                if (result == null){
                    call(threadName);
                } else {
                    System.out.println("Minute " + currentMinute + ", HTTP 200 " + threadName);
                }
            } else {
                int currentSeconds = Calendar.getInstance().get(Calendar.SECOND);
                int remainingSeconds = 60 - currentSeconds;
                jedis.expire(minuteKeyInNS, remainingSeconds);
                System.out.println("Minute " + currentMinute + ", HTTP 200 " + threadName);
            }
        }
    }

}
