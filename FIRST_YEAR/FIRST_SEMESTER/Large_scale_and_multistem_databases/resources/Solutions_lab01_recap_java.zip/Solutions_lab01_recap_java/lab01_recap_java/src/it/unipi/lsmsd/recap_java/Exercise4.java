package it.unipi.lsmsd.recap_java;

import java.util.Scanner;

public class Exercise4 {

    public static void main(String[] args){
        Scanner scanner = new Scanner(System.in);
        int n = scanner.nextInt();
        int maxValue = -1;
        for(int i = 0; i < n; i++){
            int curValue = scanner.nextInt();
            if (curValue > maxValue) {
                maxValue = curValue;
            }
        }
        System.out.format("The greatest value is: %d", maxValue);
    }
}
