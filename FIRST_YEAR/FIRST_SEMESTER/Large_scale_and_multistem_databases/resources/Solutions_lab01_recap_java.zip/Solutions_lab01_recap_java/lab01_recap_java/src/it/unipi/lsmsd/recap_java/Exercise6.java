package it.unipi.lsmsd.recap_java;

import java.util.Scanner;

public class Exercise6 {

    public long fibonacciRecursive(int n) {
        if (n == 0) {
            return 0;
        }
        else if (n == 1 || n == 2) {
            return 1;
        }
        return fibonacciRecursive(n - 1) + fibonacciRecursive(n - 2);
    }

    public long fibonacciIterative(int n){
        long[] dp = new long[n + 1];
        dp[0] = 0;
        dp[1] = 1;
        for(int i = 2; i <= n; i++){
            dp[i] = dp[i - 1] + dp[i - 2];
        }
        return dp[n];
    }

    public static void main(String[] args){

        Scanner scanner = new Scanner(System.in);
        int n = scanner.nextInt();

        Exercise6 exercise6 = new Exercise6();

        System.out.println("Computing Fibonacci in a recursive way...");
        long start = System.currentTimeMillis();
        long fibonacciResult = exercise6.fibonacciRecursive(n);
        long executionTime = System.currentTimeMillis() - start;

        System.out.format("Fibonacci recursive result: %d \n", fibonacciResult);
        System.out.format("Execution time in MS: %d \n", executionTime);

        System.out.println("Computing Fibonacci in an interative way...");
        start = System.currentTimeMillis();
        fibonacciResult = exercise6.fibonacciIterative(n);
        executionTime = System.currentTimeMillis() - start;

        System.out.format("Fibonacci interative result: %d \n", fibonacciResult);
        System.out.format("Execution time in MS: %d \n", executionTime);

    }
}
