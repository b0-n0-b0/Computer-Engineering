package it.unipi.lsmsd.recap_java;

import java.util.Scanner;

public class Exercise5 {

    public static void main(String[] args){
        Scanner scanner = new Scanner(System.in);
        int n = scanner.nextInt();
        int sum = 0;
        for(int i = 0; i < n - 1; i++){
            int curValue = scanner.nextInt();
            sum += curValue;
        }
        int missingValue = (int)((n * (n + 1) * 0.5) - sum);
        System.out.format("%d", missingValue);
    }
}
