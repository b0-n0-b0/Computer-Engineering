package it.unipi.lsmsd.recap_java;

import java.util.Scanner;

public class Exercise2 {

    public static final String LOWERCASE_VOWELS = "aeiou";

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Input the string: ");
        String enteredString = scanner.nextLine();
        int vowelsCounter = 0;
        for(int i = 0; i < enteredString.length(); i++){
            if (LOWERCASE_VOWELS.indexOf(enteredString.charAt(i)) != -1){
                vowelsCounter++;
            }
        }
        System.out.format("Number of Vowels in the string: %d", vowelsCounter);
    }
}
