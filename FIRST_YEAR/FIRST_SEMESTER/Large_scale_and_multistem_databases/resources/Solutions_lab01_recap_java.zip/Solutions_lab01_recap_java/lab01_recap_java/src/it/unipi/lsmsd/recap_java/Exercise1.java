package it.unipi.lsmsd.recap_java;

import java.util.Scanner;

public class Exercise1 {

    public static void main(String[] args){
        Scanner scanner = new Scanner(System.in);
        int n = 3;
        int maxValue = -1;
        String[] messages = {"Input the 1st number: ", "Input the 2nd number: ", "Input the 3rd number: "};
        for(int i = 0; i < n; i++){
            System.out.print(messages[i]);
            int curValue = scanner.nextInt();
            if (curValue > maxValue) {
                maxValue = curValue;
            }
        }
        System.out.format("The greatest value is: %d", maxValue);
    }
}
