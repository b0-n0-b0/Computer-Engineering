package it.unipi.lsmsd.recap_java;

public class Exercise0 {

    public static void main(String[] args){
        System.out.println("Hello World!");
    }

}
