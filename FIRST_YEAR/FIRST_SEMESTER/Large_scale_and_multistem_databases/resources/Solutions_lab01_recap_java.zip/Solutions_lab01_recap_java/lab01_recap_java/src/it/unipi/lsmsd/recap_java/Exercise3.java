package it.unipi.lsmsd.recap_java;

import java.util.ArrayList;
import java.util.List;

public class Exercise3 {

    public static void main(String[] args){
        List<String> colors = new ArrayList<String>();
        colors.add("Red");
        colors.add("Green");
        colors.add("Orange");
        colors.add("White");
        colors.add("Black");
        System.out.format("First element: %s\n", colors.get(0));
        System.out.format("Third element: %s", colors.get(2));
    }

}
